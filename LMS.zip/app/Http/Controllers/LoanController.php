<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class LoanController extends Controller
{
    // Auth Middleware restricts access to this controller to only authorized users
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function show($loan)
    {
        // Get the sum of the loan remittances
        $getSum = DB::table('loan_remittances')
                    ->selectRaw('SUM(loan_remittances.amount) as sum')
                    ->where('loan_remittances.loan_id', $loan)
                    ->get();

        // Get the total interested amount of the loan
        $getTotal = DB::table('loans')
                    ->select('loans.interested_amount as amount')
                    ->where('loans.id', $loan)
                    ->get();

        // If the loan is fully paid, change the loan status to fully paid
        // if ($getSum->first()->sum >= $getTotal->first()->amount)
        // {
        //     $changeStatus = DB::table('loans')->update(
        //                     [
        //                         'loan_status_id' => 2
        //                     ]);
        // }

        $details = $this->getLoanDetails($loan);

    	return view('loans.index')->with('details', $details);
    }

    public function getLoanDetails($loan_id)
    {
    	// Gets all the latest ledgers with their associated column data from other tables
    	$query = DB::table('loans')
    				->leftJoin('borrowers', 'loans.borrower_id', '=', 'borrowers.id')
    				->leftJoin('companies', 'borrowers.company_id', '=', 'companies.id')
                    ->leftJoin('cash_advance_status', 'loans.cash_advance_status_id', '=', 'cash_advance_status.id')
                    ->leftJoin('term_type', 'loans.term_type_id', '=', 'term_type.id')
    				->leftJoin('loan_status', 'loans.loan_status_id', '=', 'loan_status.id')
    				->select('loans.*', 'borrowers.name as borrower_name', 'companies.name as company_name', 'cash_advance_status.name as cash_advance_status', 'term_type.name as term_type', 'loan_status.name as loan_status')
    				->where('loans.id', $loan_id)
                    ->get();

    	return $query;
    }
}
