@extends('layouts.master')


@section ('content')

<div class="modal fade" id="addLoanModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Loan Record</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

        <!-- Nav Tabs -->
        <ul class="nav nav-tabs" id="addLoanRecordFormTab" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" id="new-borrower-tab" data-toggle="tab" href="#new" role="tab">New Borrower</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="existing-borrower-tab" data-toggle="tab" href="#existing" role="tab">Existing Borrower</a>
            </li>
        </ul>

        <!-- Tab Contents -->
        <div class="tab-content" id="addLoanFormTabContent">
            <div class="tab-pane fade show active" id="new" role="tabpanel">
                <form id="addLoanRecordForm1" style="padding-top: 1em;">
                    {{ csrf_field() }}
                  <div class="form-group">
                    <label for="addBorrowerCompany1" class="form-control-label">Borrower Company:</label>
                    <select class="form-control" id="addBorrowerCompany1" name="addBorrowerCompany1">
                      <option value="1">-No Company (Default)-</option>
        
                      @foreach ($companies as $company)
                        @if ($company->id != 1)
                          <option value="{{ $company->id }}">{{ $company->name }}</option>
                        @endif
                      @endforeach
        
                    </select>
                  </div>
                  <div class="form-group">
                    <label for="addBorrowerName1" class="form-control-label">Borrower Name:</label>
                    <input type="text" class="form-control" id="addBorrowerName1" name="addBorrowerName1">
                  </div>
                  <div class="row">
                      <div class="form-group col">
                        <label for="addBorrowerDate1" class="form-control-label">Date of Loan:</label>
                        <input name="addBorrowerDate1" id="addBorrowerDate1" class="form-control    datepicker" value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" data-date-format= "yyyy-mm-dd">
                      </div>
                      <div class="form-group col">
                        <label for="addLoanAmount1" class="form-control-label">Loan Amount:</label>
                        <input type="number" name="addLoanAmount1" class="form-control">
                      </div>
                    </div>
                  <div class="row">
                      <div class="form-group col">
                         <label for="addBorrowerTerm1" class="form-control-label">Term:</label>
                         <input type="number" class="form-control" id="addBorrowerTerm1" name="     addBorrowerTerm1">
                       </div>
                       <div class="form-group col">
                         <label for="addBorrowerPercentage1" class="form-control-label">Percentage:</label>
                         <input type="number" class="form-control" id="addBorrowerPercentage1" name="       addBorrowerPercentage1">
                       </div>
                    </div>
                </form>      
            </div>
            <div class="tab-pane fade" id="existing" role="tabpanel">
                <form id="addLoanRecordForm2" style="padding-top: 1em;">
                    {{ csrf_field() }}
                  <div class="form-group">
                    <label for="addBorrowerCompany2" class="form-control-label">Borrower Company:</label>
                    <select class="form-control" id="addBorrowerCompany2" name="addBorrowerCompany2">
                      <option value="1">-No Company (Default)-</option>
        
                      @foreach ($companies as $company)
                        @if ($company->id != 1)
                          <option value="{{ $company->id }}">{{ $company->name }}</option>
                        @endif
                      @endforeach

                    </select>
                  </div>
                  <div class="form-group" style="margin-top: -5px;">
                    <label for="addBorrowerName2" class="form-control-label">Borrower Name:</label>
                    <select class="form-control" id="addBorrowerName2" name="addBorrowerName2">
                    </select>
                  </div>
                  <div class="row">
                      <div class="form-group col">
                        <label for="addBorrowerDate2" class="form-control-label">Date of Loan:</label>
                        <input name="addBorrowerDate2" id="addBorrowerDate2" class="form-control    datepicker" value="{{ \Carbon\Carbon::now()->format('Y-m-d') }}" data-date-format= "yyyy-mm-dd">
                      </div>
                      <div class="form-group col">
                        <label for="addLoanAmount2" class="form-control-label">Loan Amount:</label>
                        <input type="number" name="addLoanAmount2" class="form-control">
                      </div>
                    </div>
                  <div class="row">
                      <div class="form-group col">
                         <label for="addBorrowerTerm2" class="form-control-label">Term:</label>
                         <input type="number" class="form-control" id="addBorrowerTerm2" name="     addBorrowerTerm2">
                       </div>
                       <div class="form-group col">
                         <label for="addBorrowerPercentage2" class="form-control-label">Percentage:</label>
                         <input type="number" class="form-control" id="addBorrowerPercentage2" name="       addBorrowerPercentage2">
                       </div>
                    </div>
                </form>  
            </div>
        </div>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" id="resetAddLoanForm">Cancel</button>
        <button type="button" class="btn btn-primary" id="submitAddLoanForm">Submit</button>
      </div>
    </div>
  </div>
</div>

    

    <div class="container-fluid">

      <h2>Master List</h2>
        <table class="datatable mdl-data-table__cell--non-numeric table-hover" cellspacing="0"
            width="100%" role="grid" style="width: 100%;">
            <thead class="thead-inverse">
                <tr>                    
                    <th>#</th>
                    <th>Name</th>
                    <th>Company</th>
                    <th>Date of Loan</th>
                    <th>Loan Amount</th>   
                    <th>Interested Amount (Return)</th>   
                    <th>Percentage</th>
                    <th>Deduction Amount</th>
                    <th>Term Type</th>
                    <th>Term</th>
                    <th>Loan Status</th>
                    <th>Cash Advance Status</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>


@endsection

@push('scripts')
    <script>
        $(document).ready(function() {

            // Instantiate the server side DataTable
            $('.datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    method : "POST",
                    url : "{{ route('masterList') }}"             
                },
                dom: 'Bfrtip',
                buttons: [
                    {
                        text: 'Add Loan Record',
                        action: function (e, dt, node, config) {
                            $('#addLoanModal').modal('show')
                        }
                    }
                ],
                "columns": [
                    { "data": "id", "name" : "loans.id" },
                    { "data": "borrower_name", "name" : "borrowers.name" },
                    { "data": "company_name", "name" : "companies.name" },
                    { "data": "created_at", "name" : "loans.created_at" },
                    { "data": "amount", "name" : "loans.amount" },                    
                    { "data": "interested_amount", "name" : "loans.interested_amount" },             
                    { "data": "percentage", "name" : "loans.percentage" },
                    { "data": "deduction", "name" : "loans.deduction" }, 
                    { "data": "term_type", "name" : "term_type.name" },
                    { "data": "term", "name" : "loans.term" },                 
                    { "data": "loan_status", "name" : "loans_status.name" },                  
                    { "data": "cash_advance_status", "name" : "cash_advance_status.name" }
                ],
                "fnRowCallback" : function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                    var id = aData.id;
                    $(nRow).attr("data-loan-id", id);
                    return nRow;
                }  
            });

            // Instantiate the DatePicker Plugin 
            $('.datepicker').datepicker();

            // Submit a POST AJAX request to add the loan record
            $('#submitAddLoanForm').click(function() {

                // Hide the modal after submitting
                $('#addLoanModal').modal('hide')

                // Check which form is filled-up and submitted
                if($('#new').hasClass('active'))
                {
                    var form = $('#addLoanRecordForm1');
                }
                else if($('#existing').hasClass('active'))
                {
                    var form = $('#addLoanRecordForm2');
                }

                // AJAX request for submiting the loan form
                $.ajax({
                    method: "POST",
                    url: "{{ route('addLoan') }}",
                    data: form.serialize(),
                    success: function(){
                        console.log("success");
                        $('.datatable').DataTable().draw(false);
                    },
                    error: function(){
                        console.log("error");
                    }
                });
            });

            // Instantiate the Selectize Plugin
            $('#addBorrowerCompany1, #addBorrowerCompany2').selectize({
                sortField: 'text'
            });

            var $select = $('#addBorrowerName2').selectize();
            var selectize = $select[0].selectize;
            var defaultBorrowers = [];

            function ajaxCallForBorrowers(){
                $.ajax({
                   method: "POST",
                   url: "{{ route('getBorrowersByCompany') }}",
                   data: { selectedCompany : $('#addBorrowerCompany2').val() },
                   dataType: 'json',
                   success: function (data){
                       defaultBorrowers = data;
                       selectize.addOption({value: 0, text: "-Please choose a borrower-"});
                       defaultBorrowers.forEach(function(entry)
                       {
                           selectize.addOption({value: entry.id, text: entry.name});
                       });
                       selectize.refreshOptions();
                       selectize.addItem(0);
                   }
                });
            }

            ajaxCallForBorrowers();            

            $('#addBorrowerCompany2').change(function (){
                selectize.clearOptions();
                ajaxCallForBorrowers();
            });     

            $('.datatable').on('click', 'tbody tr', function() {
              window.location = "/loan/" + $(this).data("loan-id");
            });     

        });
    </script>
@endpush
