<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Lending Management System</a>
      <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">

        </ul>
        <form class="form-inline mt-2 mt-md-0" method="POST" action="<?php echo e(route('logout')); ?>">
          <?php echo e(csrf_field()); ?>

          
          <div class="dropdown">
            <a class="nav-item nav-link dropdown-toggle mr-md-2" href="#" id="bd-versions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color:white">
              <?php echo e(Auth::user()->name); ?>

            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="bd-versions">
                <button class="btn btn-link" type="submit">Logout</button>
            </div>
          </div>
        </form>
      </div>
    </nav>

  <div class="container-fluid">
      <div class="row">
    <nav class="col-sm-3 col-md-2 d-none d-sm-block bg-light sidebar">
          <ul class="nav nav-pills flex-column">
            <li class="nav-item">
              <a class="nav-link <?php echo e(set_active('home')); ?>" href="<?php echo e(route('home')); ?>">Master List </a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(set_active('cash_advances')); ?>" href="<?php echo e(route('cashAdvances')); ?>">Cash Advances</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(set_active('borrowers')); ?>" href="<?php echo e(route('borrowers')); ?>">Borrowers</a>
            </li>
            <li class="nav-item">
              <a class="nav-link <?php echo e(set_active('companies')); ?>" href="<?php echo e(route('companies')); ?>">Companies</a>
            </li>
          </ul>
          
        </nav>