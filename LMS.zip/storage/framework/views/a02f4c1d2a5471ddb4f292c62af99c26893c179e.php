<?php $__env->startSection('content'); ?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-5" style="font-family: 'Raleway'; color: white;">Lending Management System</h2>
            <br><br>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <span class="anchor" id="formLogin"></span>

                    <!-- form card login -->
                    <div class="card bg-secondary" id="resetPasswordForm">
                        <div class="card-header" id="resetPasswordHead">
                            <h3 class="mb-0">Reset Password</h3>
                        </div>
                        <div class="card-body" id="resetPasswordBody"> 

                             <?php if(session('status')): ?>
                                 <div class="alert alert-success">
                                     <?php echo e(session('status')); ?>

                                 </div>
                             <?php endif; ?>
                            <form class="form" role="form" autocomplete="off" id="formLogin" method="POST" action="<?php echo e(route('password.request')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label for="email">Email Address</label>
                                    <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>

                                <button type="submit" class="btn btn-primary">Send Reset Password Email</button>
                            </form>
                        </div>
                        <!--/card-block-->
                    </div>
                    <!-- /form card login -->

                </div>


            </div>
            <!--/row-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div>
<!--/container-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $.backstretch("<?php echo e(asset('img/login-bg.jpg')); ?>");   
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>