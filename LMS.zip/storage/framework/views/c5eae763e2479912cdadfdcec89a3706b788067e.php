<?php $__env->startSection('content'); ?>


<div class="container py-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-center mb-4" style="font-family: 'Raleway'; color: white;">Lending Management System</h2>
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <span class="anchor" id="formLogin"></span>

                    <!-- form card login -->
                    <div class="card bg-secondary" id="registerForm">
                        <div class="card-header" id="registerFormHead">
                            <h3 class="mb-0">Register</h3>
                        </div>
                        <div class="card-body" id="registerFormBody">
                            <form class="form" role="form" autocomplete="off" id="formLogin" method="POST" action="<?php echo e(route('register')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                    <label for="name">Name</label>
                                    <input type="text" class="form-control" name="name" id="name" { old('name') }}" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                    <label for="email">Email Address</label>
                                    <input type="email" class="form-control" name="email" id="email" { old('email') }}" required autofocus>

                                    <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('contact') ? ' has-error' : ''); ?>">
                                    <label for="contact">Contact Number</label>
                                    <input type="number" class="form-control" name="contact" id="contact" { old('contact') }}" required autofocus>

                                    <?php if($errors->has('contact')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('contact')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>

                                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                    <label>Password</label>
                                    <input type="password" class="form-control" id="password" name="password"
                                    required="" autocomplete="new-password">

                                    <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="password-confirm" >Confirm Password</label>                                   
                                    <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                                    
                                </div>

                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">
                                        Register
                                    </button>
                                </div>
                            </form>
                        </div>
                        <!--/card-block-->
                    </div>
                    <!-- /form card login -->

                </div>


            </div>
            <!--/row-->

        </div>
        <!--/col-->
    </div>
    <!--/row-->
</div>
<!--/container-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $.backstretch("<?php echo e(asset('img/login-bg.jpg')); ?>");   
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>