<?php $__env->startSection('content'); ?>

<div class="modal fade" id="remitModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Remit to Loan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      	<form id="remitLoanForm">
      		<div class="form-control">
      			<div class="form-group">
      				<label for="remitLoanDate" class="form-control-label">Date of Loan Remittance:</label>
                    <input name="remitLoanDate" id="remitLoanDate" class="form-control datepicker" value="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" data-date-format= "yyyy-mm-dd">
      			</div>
      			<div class="form-group">
      				<label for="remitLoanAmount" class="form-control-label">Loan Remittance Amount:</label>
                    <input type="number" name="remitLoanAmount" id="remitLoanAmount" class="form-control" value="<?php echo e($details->first()->deduction); ?>">
      			</div>
      		</div>
      	</form>    
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" id="resetRemitForm">Cancel</button>
        <button type="button" class="btn btn-primary" id="submitRemitForm">Remit</button>
      </div>
      </div>
    </div>
  </div>



<div class="container">
	<h2>Loan Details</h2>

	<div class="row ">
		<ul class="list-group col-md-3">
		  <li class="list-group-item border-0"><b>Loan ID:</b> <?php echo e($details->first()->id); ?></li>
		  <li class="list-group-item border-0"><b>Date of Loan:</b> <?php echo e($details->first()->created_at); ?></li>
		  <li class="list-group-item border-0"><b>Borrower Name:</b> <?php echo e($details->first()->borrower_name); ?></li>
		  <li class="list-group-item border-0"><b>Borrower Company:</b> <?php echo e($details->first()->company_name); ?></li> 
		  <li class="list-group-item border-0">
		  	<b>Term:</b> <?php echo e(($details->first()->term)); ?> 
				<?php if($details->first()->term_type_id == 1): ?>
					<?php echo e("month/s"); ?>

				<?php else: ?>
					<?php echo e("give/s"); ?>

				<?php endif; ?>
		  </li>
		  <li class="list-group-item border-0"><hr></li>
		  <li class="list-group-item border-0">
		  	<b>Loan Status:</b> 
			<span class="badge" id="loan_status"><?php echo e($details->first()->loan_status); ?></span>
		  </li>
		  <li class="list-group-item border-0"><b>Loan Percentage:</b> <?php echo e($details->first()->percentage); ?>%</li>
		  <li class="list-group-item border-0"><b>Loan Amount:</b> <?php echo e($details->first()->amount); ?></li>
		  <li class="list-group-item border-0"><b>Interested Amount:</b> <?php echo e($details->first()->interested_amount); ?></li>
		</ul>

		<div class="col-md-9">
			<table class="datatable table-hover" cellspacing="0" role="grid" style="width:100%">
				<thead class="thead-inverse">
					<tr>
						<th>#</th>
						<th>Date of Remittance</th>
						<th>Remittance Amount</th>
					</tr>
				</thead>
				<tbody>
				</tbody>
			</table>
		</div>
	</div>
</div>	 

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script>
		$(document).ready(function (){

			// Instantiate the server side DataTable
            $('.datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    method : "POST",
                    url : "/loan/" + <?php echo e($details->first()->id); ?> + "/remittances"            
                },
                dom: 'Bfrtip',
                buttons: [
                    {
                        text: 'Remit to Loan',
                        action: function (e, dt, node, config) {
                            $('#remitModal').modal('show')
                        }
                    }
                ],
                "columns": [
                    { "data": "id", "name" : "loan_remittances.id" },
                    { "data": "date", "name" : "loan_remittances.date" },
                    { "data": "amount", "name" : "loan_remittances.amount" }
                ]
                // "fnRowCallback" : function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                //     var id = aData.id;
                //     $(nRow).attr("data-loan-id", id);
                //     return nRow;
                // }  
            });

            $('.datepicker').datepicker();

            // Submit a POST AJAX request to add the loan record
            $('#submitRemitForm').click(function() {

                // Hide the modal after submitting
                $('#remitModal').modal('hide');

                // AJAX request for submiting the loan form
                $.ajax({
                    method: "POST",
                    url: "<?php echo e(route('remitLoan')); ?>",
                    data: $('#remitLoanForm').serialize() + "&loan_id=<?php echo e($details->first()->id); ?>",
                    success: function(result){
                        console.log("success");
                        $('.datatable').DataTable().draw(false);
                        window.location = "/loan/" + <?php echo e($details->first()->id); ?>;
                    },
                    error: function(){
                        console.log("error");
                    }
                });
            });


			// Dynamically change the badge of the loan status
			if($('#loan_status').html() == "Not Paid")
			{
				$('#loan_status').attr("class", "badge badge-warning");
			}
			else if ($('#loan_status').html() == "Late")
			{
				$('#loan_status').attr("class", "badge badge-danger");
			}
			else if($('#loan_status').html() == "Paid")
			{
				$('#loan_status').attr("class", "badge badge-success");
			}
			

		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>