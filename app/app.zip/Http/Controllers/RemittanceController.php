<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class RemittanceController extends Controller
{
	// Auth Middleware restricts access to this controller to only authorized users
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function createLoan(Request $request)
    {
    	$query = DB::table('loan_remittances')->insert([
    		[
    			'loan_id' => $request->loan_id,
    			'date' => $request->remitLoanDate,
    			'amount' => $request->remitLoanAmount
    		]
    	]);

    	return Response::json($query);	
    }

}
