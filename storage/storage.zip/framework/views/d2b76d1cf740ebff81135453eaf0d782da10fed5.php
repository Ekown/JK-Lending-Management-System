<?php $__env->startSection('content'); ?>
	<h2><?php echo e($company); ?></h2>

	<div class="container-fluid">
        <table class="datatable table-hover" cellspacing="0" width="100%" role="grid" style="width: 100%;">
            <thead class="thead-inverse">
                <tr>                    
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script>
		$(document).ready(function (){

			// Instantiate the server side DataTable
            $('.datatable').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    method : "POST",
                    data : { selectedCompany : "<?php echo e($company); ?>" },  
                    url : "<?php echo e(route('getBorrowersByCompany')); ?>"             
                },
                // dom: 'Bfrtip',
                // buttons: [
                //     {
                //         text: 'Add Company',
                //         action: function (e, dt, node, config) {
                //             $('#addCompanyModal').modal('show')
                //         }
                //     }
                // ],
                "columns": [
                    { "data": "name", "name" : "borrowers.name" }
                ]
                // "fnRowCallback" : function (nRow, aData, iDisplayIndex, iDisplayIndexFull) {

                //     var id = aData.company_name;
                //     $(nRow).attr("data-company-name", id);
                //     return nRow;
                // } 
            });

		});
	</script>
<?php $__env->stopPush(); ?>	
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>